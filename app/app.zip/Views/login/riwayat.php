<?= $this->extend('/layout/base_user'); ?>

<?= $this->section('content'); ?>
<div class="container my-4">
    <div class="header text-center mb-4">Riwayat</div>

    <?php
    if (!empty($dataRiwayat)) { ?>
        <?php foreach ($dataRiwayat as $r) : ?>
            <div class="card mb-4">
                <div class="card-body p-4 d-flex">
                    <div class="col-3">
                        <h5>Tanggal Pembelian</h5>
                        <h2><b><?= $r['tanggal_pembayaran']; ?></b></h2>
                    </div>
                    <div class="col">
                        <h5>Status</h5>
                        <div class="
                        <?= ($r['status_pembayaran'] == 'Menunggu Pembayaran') ? 'btn btn-kuning' : ''; ?>
                        <?= ($r['status_pembayaran'] == 'Menunggu Konfirmasi Admin') ? 'btn btn-hijau' : ''; ?>
                        <?= ($r['status_pembayaran'] == 'Gagal') ? 'btn btn-merah' : ''; ?>
                        <?= ($r['status_pembayaran'] == 'Batal') ? 'btn btn-merah' : ''; ?>
                        <?= ($r['status_pembayaran'] == 'Barang Dikirim') ? 'btn btn-hijau' : ''; ?>
                        "><?= $r['status_pembayaran']; ?></div>
                    </div>
                </div>

                <div class="card-body py-0">
                    <div class="card">
                        <div class="card-body p-3 d-flex justify-content-between">
                            <div>
                                <img src="/Assets/fotojaket/<?= $r['foto_jaket']; ?>" class="rounded" width="160px" alt="">
                            </div>
                            <div class="detail-keranjang my-auto mx-5">
                                <h2 class="nama-jaket"><b><?= $r['nama_jaket']; ?></b></h2>
                                <h2 class="harga-jaket"><b>Rp <?= $r['harga']; ?></b></h2>
                                <div class="btn btn-2"><?= $r['ukuran']; ?></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card-body px-4 py-3 d-flex">
                    <div class="col-3">
                        <h5>Total</h5>
                        <h2><b>Rp <?= $r['total'] + $r['ongkos_kirim']; ?></b></h2>
                    </div>
                </div>

                <div class="row card-body pt-0">
                    <div class="col d-grid">
                        <a <?= ($r['status_bayar'] == true || $r['status_pembayaran'] == 'Gagal') ? 'class="btn btn-disable"' : 'href="/pembayaran/' . $r['id_order'] . '" class="btn btn-1"'; ?>>Bayar</a>
                    </div>
                    <div class="col d-grid">
                        <a href="/riwayat/detailRiwayat/<?= $r['id_order']; ?>" class="btn btn-2">Rincian</a>
                    </div>
                </div>
            </div>
        <?php endforeach ?>
    <?php } else { ?>
        <div class="row mb-4 text-center">
            <img src="/Assets/not-found.svg" class="image-keranjang" height="400px" alt="">
            <h1 class="keranjang-alert text-center"><b>Riwayat Kosong</b></h1>
            <p>Silahkan lakukan pembelian terlabih dahulu</p>
            <div class="d-grid mt-2 mb-4">
                <a href="/login/katalog" class="btn btn-1 px-auto">Lanjut</a>
            </div>
        </div>
    <?php } ?>
</div>
<?= $this->endSection(); ?>