<?= $this->extend('layout/base_user'); ?>

<?= $this->section('content'); ?>
<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-6 rounded border py-4 px-5">
            <div class="row">
                <div class="col">
                    <div class="header text-center mb-4">Ganti Kata Sandi</div>
                </div>
            </div>

            <?php if (!empty(session()->getFlashdata('pesan'))) : ?>
                <div class="alert alert-success" role="alert">
                    <?php echo session()->getFlashdata('pesan'); ?>
                </div>
            <?php endif; ?>

            <?php if (!empty(session()->getFlashdata('error'))) : ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo session()->getFlashdata('error'); ?>
                </div>
            <?php endif; ?>

            <form action="/profil/gantiKataSandi/update/<?= session()->get('id_user'); ?>" method="post">
                <div class="my-3">
                    <label for="kataSandiBaru" class="form-label">Kata Sandi Baru</label>
                    <input type="password" class="form-control" id="kataSandiBaru" name="password" aria-describedby="kataSandiBaru">
                </div>
                <!-- <div class="my-3">
                    <label for="konfirmasiKataSandi" class="form-label">Konfirmasi Kata Sandi</label>
                    <input type="password" class="form-control" id="konfirmasiKataSandi" aria-describedby="konfirmasiKataSandi">
                </div> -->
                <div class="d-grid gap-2 mt-5">
                    <button class="btn btn-1" type="submit">Simpan</button>
                    <a href="/profil/<?= session()->get('id_user'); ?>" class="btn btn-2">Kembali</a>
                </div>
            </form>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>