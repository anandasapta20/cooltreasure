<?= $this->extend('layout/base_user'); ?>

<?= $this->section('content'); ?>
<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-6 rounded border py-4 px-5">
            <div class="row">
                <div class="col">
                    <div class="header text-center mb-4">Profil</div>
                </div>
            </div>
            <form method="post" action="/profil/update/<?= session()->get('id_user'); ?>" enctype="multipart/form-data">

                <?php if (!empty(session()->getFlashdata('pesan'))) : ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo session()->getFlashdata('pesan'); ?>
                    </div>
                <?php endif; ?>

                <?php if (!empty(session()->getFlashdata('error'))) : ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo session()->getFlashdata('error'); ?>
                    </div>
                <?php endif; ?>

                <input type="hidden" name="id_user" id="id_user" value="<?= session()->get('id_user'); ?>">
                <input type="hidden" name="nama_foto_profil_lama" value="<?= $dataUser['foto_profil']; ?>">

                <div class="text-center">
                    <img src="/Assets/fotoprofil/<?= $dataUser['foto_profil']; ?>" alt="foto-profil" height="160px" width="160px" class="foto-profil">
                </div>

                <div class="my-3">
                    <label for="foto_profil" class="form-label label-foto">Foto Profil</label>
                    <input type="file" class="form-control" id="foto_profil" name="foto_profil" aria-describedby="foto_profil" value="<?= $dataUser['foto_profil']; ?>" onchange="previewImg()">
                    <div class="col-sm-4 mt-2">
                        <img src="/Assets/fotoJaket/default.png" class="img-preview foto-profil" alt="">
                    </div>
                </div>
                <div class="my-3">
                    <label for="nama_lengkap" class="form-label">Nama Lengkap</label>
                    <input type="text" class="form-control" id="nama_lengkap" name="nama_lengkap" aria-describedby="nama_lengkap" value="<?= $dataUser['nama_lengkap']; ?>">
                </div>
                <div class="my-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" aria-describedby="email" value="<?= $dataUser['email']; ?>">
                </div>
                <div class="my-3">
                    <label for="no_hp" class="form-label">Nomor Handphone</label>
                    <input type="number" class="form-control" id="no_hp" name="no_hp" aria-describedby="no_hp" value="<?= $dataUser['no_hp']; ?>">
                </div>
                <a href="/profil/gantiKataSandi/<?= session()->get('id_user'); ?>" class="btn btn-3 my-3 detail-keranjang">Ganti Kata Sandi</a>

                <div class="row">
                    <div class="col">
                        <div class="header text-center my-4">Data Pengiriman</div>
                    </div>
                </div>
                <div class="my-3">
                    <label for="alamat" class="form-label">Alamat</label>
                    <input type="text" class="form-control" id="alamat" name="alamat" aria-describedby="alamat" value="<?= $dataUser['alamat']; ?>">
                </div>
                <div class="my-3">
                    <label for="rt_rw" class="form-label">RT/RW</label>
                    <input type="text" class="form-control" id="rt_rw" name="rt_rw" aria-describedby="rt_rw" value="<?= $dataUser['rt_rw']; ?>">
                </div>
                <div class="my-3">
                    <label for="kelurahan_desa" class="form-label">Kelurahan/Desa</label>
                    <input type="text" class="form-control" id="kelurahan_desa" name="kelurahan_desa" aria-describedby="kelurahan_desa" value="<?= $dataUser['kelurahan_desa']; ?>">
                </div>
                <div class="my-3">
                    <label for="kecamatan" class="form-label">Kecamatan</label>
                    <input type="text" class="form-control" id="kecamatan" name="kecamatan" aria-describedby="kecamatan" value="<?= $dataUser['kecamatan']; ?>">
                </div>
                <div class="my-3">
                    <label for="kabupaten_kota" class="form-label">Kabupaten/Kota</label>
                    <input type="text" class="form-control" id="kabupaten_kota" name="kabupaten_kota" aria-describedby="kabupaten_kota" value="<?= $dataUser['kabupaten_kota']; ?>">
                </div>
                <div class="my-3">
                    <label for="provinsi" class="form-label">Provinsi</label>
                    <input type="text" class="form-control" id="provinsi" name="provinsi" aria-describedby="provinsi" value="<?= $dataUser['provinsi']; ?>">
                </div>
                <div class="my-3">
                    <label for="kode_pos" class="form-label">Kode Pos</label>
                    <input type="text" class="form-control" id="kode_pos" name="kode_pos" aria-describedby="kode_pos" value="<?= $dataUser['kode_pos']; ?>">
                </div>

                <div class="d-grid gap-2 mt-5">
                    <button class="btn btn-1" type="submit">Simpan</button>
                    <a href="/keluarAkun" class="btn btn-2">Keluar Akun</a>
                </div>
            </form>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>