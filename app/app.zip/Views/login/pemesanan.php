<?= $this->extend('layout/base_user'); ?>

<?= $this->section('content'); ?>
<div class="container my-5">
    <div class="row">
        <div class="col-5 mx-auto border rounded px-5 py-4">
            <div class="header text-center mb-4">Pemesanan</div>

            <?php if (!empty(session()->getFlashdata('error'))) : ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo session()->getFlashdata('error'); ?>
                </div>
            <?php endif; ?>

            <form action="/pemesanan/save/<?= $jaket['id_jaket']; ?>" method="post">
                <input type="hidden" name="user_id" value="<?= $dataUser['id_user']; ?>">
                <input type="hidden" name="jaket_id" value="<?= $jaket['id_jaket']; ?>">

                <div class="mb-3">
                    <label for="alamat" class="form-label">Alamat</label>
                    <input type="text" class="form-control" id="alamat" name="alamat" value="<?= $dataUser['alamat']; ?>">
                </div>
                <div class="mb-3">
                    <label for="rtrw" class="form-label">RT/RW</label>
                    <input type="text" class="form-control" id="rtrw" name="rt_rw" value="<?= $dataUser['rt_rw']; ?>">
                </div>
                <div class="mb-3">
                    <label for="kelurahan_desa" class="form-label">Kelurahan/Desa</label>
                    <input class="form-control" id="kelurahan_desa" name="kelurahan_desa" value="<?= $dataUser['kelurahan_desa']; ?>">
                </div>
                <div class="mb-3">
                    <label for="kecamatan" class="form-label">Kecamatan</label>
                    <input type="text" class="form-control" id="kecamatan" name="kecamatan" value="<?= $dataUser['kecamatan']; ?>">
                </div>
                <div class="mb-3">
                    <label for="kabupatenkota" class="form-label">Kabupaten/Kota</label>
                    <input type="text" class="form-control" id="kabupatenkota" name="kabupaten_kota" value="<?= $dataUser['kabupaten_kota']; ?>">
                </div>
                <div class="mb-3">
                    <label for="provinsi" class="form-label">Provinsi</label>
                    <input type="text" class="form-control" id="provinsi" name="provinsi" value="<?= $dataUser['provinsi']; ?>">
                </div>
                <div class="mb-3">
                    <label for="kodepos" class="form-label">Kode Pos</label>
                    <input type="text" class="form-control" id="kodepos" name="kode_pos" value="<?= $dataUser['kode_pos']; ?>">
                </div>
                <div class="mb-3">
                    <label for="mpembayaran_id" class="form-label">Metode Pembayaran</label>
                    <select class="form-select" name="mpembayaran_id">
                        <?php foreach ($metodePembayaran as $mpemb) : ?>
                            <option value="<?= $mpemb['id_mpembayaran']; ?>"><?= $mpemb['nama_bank_wallet']; ?></option>
                        <?php endforeach ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="mpengiriman_id" class="form-label">Metode Pengiriman</label>
                    <select class="form-select" name="mpengiriman_id">
                        <?php foreach ($metodePengiriman as $mpeng) : ?>
                            <option value="<?= $mpeng['id_mpengiriman']; ?>"><?= $mpeng['ekspedisi']; ?></option>
                        <?php endforeach ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="total" class="form-label mb-0">Subtotal</label>
                    <h1 class="total"><b>Rp <?= $jaket['harga']; ?></b></h1>
                </div>
                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-1">Bayar</button>
                    <a href="/login/detailJaket/<?= $jaket['id_jaket']; ?>" class="btn btn-2">Kembali</a>
                </div>
            </form>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>