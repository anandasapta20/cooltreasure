<?= $this->extend('layout/base_user'); ?>

<?= $this->section('content'); ?>
<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-8 rounded border py-4 px-5">
            <div class="row">
                <div class="col">
                    <div class="header text-center mb-4">Detail Riwayat Pembelian</div>
                </div>
            </div>

            <div class="card-body py-0 mb-3">
                <div class="card">
                    <div class="card-body p-3 d-flex justify-content-between">
                        <div>
                            <img src="/Assets/fotojaket/<?= $dataRiwayat['foto_jaket']; ?>" class="rounded" width="140px" alt="">
                        </div>
                        <div class="detail-keranjang my-auto mx-4">
                            <h2 class="detail-riwayat-jaket"><b><?= $dataRiwayat['nama_jaket']; ?></b></h2>
                            <h2 class="detail-riwayat-harga"><b>Rp <?= $dataRiwayat['harga']; ?></b></h2>
                            <div class="btn btn-2"><?= $dataRiwayat['ukuran']; ?></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col">
                    <p class="mb-0">Alamat</p>
                    <h4 class="mb-0"><?= $dataRiwayat['alamat']; ?></h4>
                </div>
            </div>
            <div class="row my-4">
                <div class="col">
                    <p class="mb-0">RT/RW</p>
                    <h4 class="mb-0"><?= $dataRiwayat['rt_rw']; ?></h4>
                </div>
                <div class="col">
                    <p class="mb-0">Kelurahan/Desa</p>
                    <h4 class="mb-0"><?= $dataRiwayat['kelurahan_desa']; ?></h4>
                </div>
            </div>
            <div class="row my-4">
                <div class="col">
                    <p class="mb-0">Kecamatan</p>
                    <h4 class="mb-0"><?= $dataRiwayat['kecamatan']; ?></h4>
                </div>
                <div class="col">
                    <p class="mb-0">Kabupaten/Kota</p>
                    <h4 class="mb-0"><?= $dataRiwayat['kabupaten_kota']; ?></h4>
                </div>
            </div>
            <div class="row my-4">
                <div class="col">
                    <p class="mb-0">Provinsi</p>
                    <h4 class="mb-0"><?= $dataRiwayat['provinsi']; ?></h4>
                </div>
                <div class="col">
                    <p class="mb-0">Kode Pos</p>
                    <h4 class="mb-0"><?= $dataRiwayat['kode_pos']; ?></h4>
                </div>
            </div>
            <div class="row my-4">
                <div class="col">
                    <p class="mb-0">Metode Pengiriman</p>
                    <h4 class="mb-0"><?= $dataRiwayat['ekspedisi']; ?></h4>
                </div>
                <div class="col">
                    <p class="mb-0">Tanggal Pembelian</p>
                    <h4 class="mb-0"><?= $dataRiwayat['tanggal_pembelian']; ?></h4>
                </div>
            </div>

            <div class="row my-4">
                <div class="col">
                    <p class="mb-0">Metode Pembayaran</p>
                    <h4 class="mb-0"><?= $dataRiwayat['nama_bank_wallet']; ?></h4>
                </div>
                <div class="col">
                    <p class="mb-0">Nomor Rekening</p>
                    <h4 class="mb-0"><?= $dataRiwayat['norek_nohp']; ?></h4>
                </div>
            </div>
            <div class="row my-4">
                <div class="col">
                    <p class="mb-0">Total Pembayaran</p>
                    <h4 class="total mb-0"><b>Rp <?= $dataRiwayat['harga'] + $dataRiwayat['ongkos_kirim']; ?></b></h4>
                </div>
            </div>
            <div class="row my-4">
                <div class="col">
                    <p class="mb-0">Bukti Pembayaran</p>
                    <img src="/Assets/fotobukti/<?= $dataRiwayat['foto_bukti']; ?>" width="100px" alt="">
                </div>
            </div>

            <div class="d-grid gap-2 mt-5">
                <a <?= ($dataRiwayat['status_ulasan'] == true || $dataRiwayat['status_bayar'] == false || $dataRiwayat['status_pembayaran'] == 'Gagal') ? 'class="btn btn-disable"' : 'href="/riwayat/detailRiwayat/ulasan/' . $dataRiwayat['id_order'] . '" class="btn btn-1"'; ?>>Berikan Ulasan</a>
                <a href="/riwayat" class="btn btn-2">Kembali</a>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>