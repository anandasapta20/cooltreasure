<?= $this->extend('layout/base_user'); ?>

<?= $this->section('content'); ?>
<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-8 rounded border p-5">
            <div class="row">
                <div class="col">
                    <div class="header text-center mb-4">Pembayaran</div>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <p class="mb-0">Batas Akhir Pembayaran</p>
                    <h4 class="total"><b>59:59</b></h4>
                </div>
            </div>
            <div class="row my-4">
                <div class="col">
                    <p class="mb-0">Metode Pembayaran</p>
                    <h4 class="mb-0"><?= $dataPembayaran['nama_bank_wallet']; ?></h4>
                </div>
                <div class="col">
                    <p class="mb-0">Nomor Rekening</p>
                    <h4 class="mb-0"><?= $dataPembayaran['norek_nohp']; ?></h4>
                </div>
            </div>
            <div class="">
                <p class="mb-0">Total Pembayaran</p>
                <h4 class="total"><b>Rp <?= $dataPembayaran['total'] + $dataPembayaran['ongkos_kirim']; ?></b></h4>
            </div>

            <?php if (session()->getFlashdata('error')) : ?>
                <div class="alert alert-danger mt-4" role="alert">
                    <?= session()->getFlashdata('error'); ?>
                </div>
            <?php endif; ?>

            <form action="/pembayaran/update/<?= $dataPembayaran['id_order']; ?>" method="post" enctype="multipart/form-data">
                <div class="my-4">
                    <label for="foto_bukti" class="form-label label-foto">Bukti Pembayaran</label>
                    <input class="form-control" type="file" id="foto_bukti" name="foto_bukti" onchange="previewImgBayar()">
                    <div class="col-sm-4 mt-2">
                        <img src="/Assets/fotoJaket/default.png" class="img-thumbnail img-preview" alt="">
                    </div>
                </div>
                <div class="d-grid gap-2 mt-5">
                    <button class="btn btn-1" type="submit">Simpan</button>
                    <a href="/pembayaran/batal/<?= $dataPembayaran['id_order']; ?>" class="btn btn-2">Batalkan</a>
                    <a href="/riwayat" class="btn btn-3">Kembali</a>
                </div>
            </form>

        </div>
    </div>
</div>

<?= $this->endSection(); ?>