<?= $this->extend('layout/base_admin'); ?>

<?= $this->section('content'); ?>
<div class="container my-5">
    <div class="row">
        <div class="col">
            <div class="header text-center mb-4">Daftar Pengguna</div>
        </div>
    </div>
    <?php if (session()->getFlashdata('pesan')) : ?>
        <div class="alert alert-success" role="alert">
            <?= session()->getFlashdata('pesan'); ?>
        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col">
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">No.</th>
                        <th scope="col">Nama Lengkap</th>
                        <th scope="col">Email</th>
                        <th scope="col">Nomor Handphone</th>
                        <th scope="col">Data Pengiriman</th>
                        <th scope="col">Foto Profil</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody class="table-group-divider">
                    <?php $i = 1; ?>
                    <?php foreach ($user as $j) : ?>
                        <tr>
                            <th scope="row"><?= $i++; ?></th>
                            <td><?= $j['nama_lengkap']; ?></td>
                            <td><?= $j['email']; ?></td>
                            <td><?= $j['no_hp']; ?></td>
                            <td><a href="/admin/pengguna/<?= $j['id_user']; ?>"><button class="btn btn-primary" type="button">Detail</button></a></td>
                            <td><img src="/Assets/fotoprofil/<?= $j['foto_profil']; ?>" class="foto-profil-admin" alt="user"></td>
                            <td><a href="/admin/daftarPengguna/delete/<?= $j['id_user']; ?>" class="btn btn-danger">Hapus</a></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?= $this->endSection(); ?>