<?= $this->extend('/layout/base_admin'); ?>

<?= $this->section('content'); ?>
<div class="container my-5">
    <div class="row">
        <div class="col">
            <div class="header text-center mb-4">Daftar Pembelian</div>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">No.</th>
                        <th scope="col">Nama Pengguna</th>
                        <th scope="col">Pembelian Jaket</th>
                        <th scope="col">Metode Pembayaran</th>
                        <th scope="col">Metode Pengiriman</th>
                        <th scope="col">Status</th>
                        <th scope="col">Tanggal Pembelian</th>
                        <th scope="col">Tanggal Pembayaran</th>
                        <th scope="col">Total</th>
                        <th scope="col">Foto Bukti</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody class="table-group-divider">
                    <?php $i = 1; ?>
                    <?php foreach ($pembelian as $p) : ?>
                        <tr>
                            <th scope="row"><?= $i++; ?></th>
                            <td>
                                <?= $p['nama_lengkap']; ?>
                                <a href="/admin/pengguna/<?= $p['id_user']; ?>" class="btn btn-primary mt-2">Detail</a>
                            </td>
                            <td><?= $p['nama_jaket']; ?></td>
                            <td><?= $p['nama_bank_wallet']; ?></td>
                            <td><?= $p['ekspedisi']; ?></td>
                            <td>
                                <div class="
                                <?= ($p['status_pembayaran'] == 'Menunggu Pembayaran') ? 'btn btn-kuning' : ''; ?>
                                <?= ($p['status_pembayaran'] == 'Menunggu Konfirmasi Admin') ? 'btn btn-hijau' : ''; ?>
                                <?= ($p['status_pembayaran'] == 'Gagal') ? 'btn btn-merah' : ''; ?>
                                <?= ($p['status_pembayaran'] == 'Batal') ? 'btn btn-merah' : ''; ?>
                                <?= ($p['status_pembayaran'] == 'Barang Dikirim') ? 'btn btn-hijau' : ''; ?>
                                ">
                                    <b class="status-bayar"><?= $p['status_pembayaran']; ?></b>
                                </div>
                            </td>
                            <td><?= $p['created_at']; ?></td>
                            <td><?= $p['updated_at']; ?></td>
                            <td>Rp <?= $p['harga'] + $p['ongkos_kirim']; ?></td>
                            <td><img src="/Assets/fotobukti/<?= $p['foto_bukti']; ?>" width="100px" alt=""></td>
                            <td>
                                <a href="/admin/daftarPembelian/terima/<?= $p['id_order']; ?>" class="btn btn-success mb-2">Terima</a>
                                <a href="/admin/daftarPembelian/tolak/<?= $p['id_order']; ?>" class="btn btn-danger">Tolak</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>