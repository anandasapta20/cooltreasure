<?= $this->extend('layout/base_admin'); ?>

<?= $this->section('content'); ?>
<div class="container my-5">
    <div class="row">
        <div class="col">
            <a href="/admin/daftarJaket/tambahJaket"><button class="btn btn-1" type="button">Tambah Jaket <img src="/Assets/icon/add.png" width="24px" alt="add"></button></a>
        </div>
        <div class="col">
            <div class="header text-center mb-4">Daftar Jaket</div>
        </div>
        <div class="col"></div>
    </div>
    <?php if (session()->getFlashdata('pesan')) : ?>
        <div class="alert alert-success" role="alert">
            <?= session()->getFlashdata('pesan'); ?>
        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col">
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">No.</th>
                        <th scope="col">Nama Jaket</th>
                        <th scope="col">Ukuran</th>
                        <th scope="col">Kondisi</th>
                        <th scope="col">Harga</th>
                        <th scope="col">Jenis</th>
                        <th scope="col">Foto</th>
                        <th scope="col">Aksi</th>
                    </tr>
                </thead>
                <tbody class="table-group-divider">
                    <?php $i = 1; ?>
                    <?php foreach ($jaket as $j) : ?>
                        <tr>
                            <th scope="row"><?= $i++; ?></th>
                            <td><?= $j['nama_jaket']; ?></td>
                            <td><?= $j['ukuran']; ?></td>
                            <td><?= $j['kondisi']; ?></td>
                            <td>Rp <?= $j['harga']; ?></td>
                            <td><?= $j['jenis']; ?></td>
                            <td><img src="/Assets/fotojaket/<?= $j['foto_jaket']; ?>" class="data-foto-jaket" alt="jaket"></td>
                            <td>
                                <a href="/admin/daftarJaket/ubahJaket/<?= $j['id_jaket']; ?>" class="btn btn-warning mb-2">Ubah</a>
                                <a href="/admin/daftarJaket/delete/<?= $j['id_jaket']; ?>" class="btn btn-danger">Hapus</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>