<?php

namespace App\Controllers;

use \App\Models\UserModel;

class UserGantiKataSandi extends BaseController
{
    protected $userModel;
    public function __construct()
    {
        $this->userModel = new UserModel();
    }

    public function index($id)
    {
        $data = [
            'title' => 'Ganti Kata Sandi | Cooltreasure.id',
            'dataUser' => $this->userModel->getUser($id)
        ];

        return view('login/gantiKataSandi', $data);
    }

    public function update($id)
    {
        if (!$this->validate([
            'password' => [
                'rules' => 'required|min_length[4]|max_length[24]',
                'errors' => [
                    'required' => '{field} Harus diisi.',
                    'min_length' => '{field} Minimal 4 Karakter.',
                    'max_length' => '{field} Maksimal 24 Karakter.'
                ]
            ]
        ])) {
            session()->setFlashdata('error', $this->validator->listErrors());
            return redirect()->to('/profil/gantiKataSandi/' . $id)->withInput();
        }

        // dd($this->request->getVar('password'));

        $users = new UserModel();
        $users->update($id, [
            'password' => password_hash($this->request->getVar('password'), PASSWORD_BCRYPT)
        ]);
        session()->setFlashdata('pesan', 'Pasword berhasil diubah.');
        return redirect()->to('/profil/' . $id);
    }
}
