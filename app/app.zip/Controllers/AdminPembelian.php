<?php

namespace App\Controllers;

use \App\Models\PembelianModel;
use \App\Models\UserModel;

class AdminPembelian extends BaseController
{
    protected $pembelianModel;
    protected $userModel;
    public function __construct()
    {
        $this->pembelianModel = new PembelianModel();
        $this->userModel = new UserModel();
    }

    public function index()
    {
        $data = [
            'title' => 'Daftar Pembelian | Admin Cooltreasure.id',
            'pembelian' => $this->pembelianModel->getPembelian()
        ];

        return view('admin/daftarPembelian', $data);
    }

    public function tolak($id)
    {
        $this->pembelianModel->update($id, [
            'status_pembayaran' => 'Gagal',
        ]);
        session()->setFlashdata('pesan', 'Pembelian jaket telah ditolak');
        return redirect()->to('/admin/daftarPembelian');
    }

    public function terima($id)
    {
        $this->pembelianModel->update($id, [
            'status_pembayaran' => 'Barang Dikirim',
        ]);
        session()->setFlashdata('pesan', 'Pembelian jaket telah diterima');
        return redirect()->to('/admin/daftarPembelian');
    }
}
