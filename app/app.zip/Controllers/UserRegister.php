<?php

namespace App\Controllers;

use \App\Models\UserModel;

class UserRegister extends BaseController
{
    public function index()
    {
        $data = [
            'title' => 'Buat Akun | Cooltreasure.id',
        ];

        return view('buatAkun', $data);
    }

    public function saveDaftar()
    {
        if (!$this->validate([
            'foto_profil' => [
                'rules' => 'max_size[foto_profil,1024]|is_image[foto_profil]',
                'errors' => [
                    'max_size' => 'Ukuran foto terlalu besar.',
                    'is_image' => 'File yang anda pilih bukan foto.'
                ]
            ],
            'nama_lengkap' => [
                'rules' => 'required|min_length[1]|max_length[255]',
                'errors' => [
                    'required' => '{field} Harus diisi.',
                    'min_length' => '{field} Minimal 4 Karakter.',
                    'max_length' => '{field} Maksimal 100 Karakter.',
                ]
            ],
            'email' => [
                'rules' => 'required|min_length[4]|max_length[255]|is_unique[user.email]',
                'errors' => [
                    'required' => '{field} Harus diisi.',
                    'min_length' => '{field} Minimal 4 Karakter.',
                    'max_length' => '{field} Maksimal 20 Karakter.',
                    'is_unique' => 'Email sudah digunakan sebelumnya.'
                ]
            ],
            'password' => [
                'rules' => 'required|min_length[4]|max_length[24]',
                'errors' => [
                    'required' => '{field} Harus diisi.',
                    'min_length' => '{field} Minimal 4 Karakter.',
                    'max_length' => '{field} Maksimal 24 Karakter.'
                ]
            ],
            'nomor_hp' => [
                'rules' => 'required|min_length[10]|max_length[20]|numeric',
                'errors' => [
                    'required' => '{field} Harus diisi.',
                    'min_length' => '{field} Minimal 10 Karakter.',
                    'max_length' => '{field} Maksimal 20 Karakter.',
                    'numeric' => '{field} Harus angka.'
                ]
            ]
        ])) {
            // dd(session());
            session()->setFlashdata('error', $this->validator->listErrors());
            return redirect()->to('/buatAkun')->withInput();
        }

        //ambil gambar
        $fileFoto = $this->request->getFile('foto_profil');
        //apakah tidak ada gambar yang diupload
        if ($fileFoto->getError() == 4) {
            $namaFoto = 'default_profil.png';
        } else {
            //pindahkan file
            $fileFoto->move('Assets/fotoprofil');
            //ambil nama file
            $namaFoto = $fileFoto->getName();
        }

        $users = new UserModel();
        $users->insert([
            'foto_profil' => $namaFoto,
            'nama_lengkap' => $this->request->getVar('nama_lengkap'),
            'email' => $this->request->getVar('email'),
            'password' => password_hash($this->request->getVar('password'), PASSWORD_BCRYPT),
            'no_hp' => $this->request->getVar('nomor_hp'),
        ]);
        return redirect()->to('/buatAkun/success');
    }
}
