<?php

namespace App\Controllers;

use \App\Models\UserModel;

class Profil extends BaseController
{
    protected $userModel;
    public function __construct()
    {
        $this->userModel = new UserModel();
    }

    public function index($id)
    {
        $data = [
            'title' => 'Profil | Cooltreasure.id',
            'dataUser' => $this->userModel->getUser($id)
        ];

        return view('/login/profil', $data);
    }

    public function update($id)
    {
        $userLama = $this->userModel->getUser($id);

        if ($this->request->getVar('nama_lengkap') == $userLama['nama_lengkap']) {
            $rule_user = 'required';
        } else {
            $rule_user = 'required|is_unique[jaket.nama_jaket]';
        }

        if (!$this->validate([
            'nama_lengkap' => [
                'rules' => $rule_user,
                'errors' => [
                    'required' => '{field} harus diisi.',
                    'is_unique' => '{field} sudah terisi.'
                ]
            ],
            'foto_profil' => [
                'rules' => 'max_size[foto_profil,1024]|is_image[foto_profil]',
                'errors' => [
                    'max_size' => 'Ukuran foto terlalu besar',
                    'is_image' => 'File yang anda pilih bukan foto'
                ]
            ]
        ])) {
            session()->setFlashdata('error', $this->validator->listErrors());
            return redirect()->to('/profil/' . $id)->withInput();
        }

        $fileFoto = $this->request->getFile('foto_profil');

        //cek gambar apakah tetap gambar lama
        if ($fileFoto->getError() == 4) {
            $namaFoto = $this->request->getVar('nama_foto_profil_lama');
        } else {
            $namaFoto = $fileFoto->getName();

            $fileFoto->move('Assets/fotoprofil', $namaFoto);

            unlink('Assets/fotoprofil/' . $this->request->getVar('nama_foto_profil_lama'));
        }

        $this->userModel->update($id, [
            'foto_profil' => $namaFoto,
            'nama_lengkap' => $this->request->getVar('nama_lengkap'),
            'email' => $this->request->getVar('email'),
            'no_hp' => $this->request->getVar('no_hp'),
            'alamat' => $this->request->getVar('alamat'),
            'rt_rw' => $this->request->getVar('rt_rw'),
            'kelurahan_desa' => $this->request->getVar('kelurahan_desa'),
            'kecamatan' => $this->request->getVar('kecamatan'),
            'kabupaten_kota' => $this->request->getVar('kabupaten_kota'),
            'provinsi' => $this->request->getVar('provinsi'),
            'kode_pos' => $this->request->getVar('kode_pos'),
        ]);

        session()->setFlashdata('pesan', 'Profil berhasil diubah.');

        return redirect()->to('/profil/' . $id);
    }

    public function gantiKataSandi()
    {
        $data = [
            'title' => 'Ganti Kata Sandi | Cooltreasure.id',
        ];

        return view('/login/gantiKataSandi', $data);
    }
}
